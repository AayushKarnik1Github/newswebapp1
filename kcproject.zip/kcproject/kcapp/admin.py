from django.contrib import admin
from .models import StudentModel
class StudentAdmin(admin.ModelAdmin):
	list_display = ("phone", "crdt")
	list_filter = ("crdt",)
admin.site.register(StudentModel, StudentAdmin)

