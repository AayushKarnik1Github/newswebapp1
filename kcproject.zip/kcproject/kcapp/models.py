from django.db import models
class StudentModel(models.Model):
	phone = models.IntegerField(primary_key=True)
	crdt = models.DateTimeField(auto_now_add=True)


	def __str__(self):
		
		return self.phone
