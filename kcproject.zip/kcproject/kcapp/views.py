from django.shortcuts import render
from .models import StudentModel

def home(request):
	if request.GET.get("btn"):
		try:
			a1 = "https://newsapi.org/v2/top-headlines"
			a2 = "?country=" + "in"
			a3 = "&apiKey=" + "3c8ad404ede24d2384c19c827a0aa87a"
			wa = a1 + a2 + a3
			res = requests.get(wa)
			data = res.json()
			info = data["articles"]
			return render(request, "home.html",{"msg":info})
		except Excption as e:
			print("issue", e)
			return render(request, "home.html",{"msg":e})
	else:
		return render(request, "home.html")

def nl(request):
	if request.method == "POST" and request.POST.get("b1"):
		ph = request.POST.get("ph")
		try:
			usr = StudentModel.objects.get(phone=ph)
			return render(request, "nl.html", {"msg":"already subscribed"})

		except StudentModel.DoesNotExist:
			data = StudentModel(phone=ph)
			data.save()
			send_sms(ph, "congrats for your subscription")
			return render(request, "nl.html", {"msg":"congrats for your subscription"})

	elif request.method == "POST" and request.POST.get("b2"):
		ph = request.POST.get("ph")
		try:
			usr = StudentModel.objects.get(phone=ph)
			usr.delete()
			send_sms(ph, "sorry to let u go")
			return render(request, "nl.html", {"msg":"sorry to let u go"})

		except StudentModel.DoesNotExist:
			return render(request, "nl.html",{"msg":"phone number not subscribed"})
	else:
		return render(request, "nl.html")


def send_sms(ph,txt):
	import requests
	url = "https://www.fast2sms.com/dev/bulkV2"
	querystring = {
	"authorization":"o4C3Y528mIUfEH0NgeRFMwDuq1Ji69d7vbBysZpjOlGXnQPhxzji41JfwHNqlG2konpOULFmeAuMTDgr",
	"variables_values":"5599",
	"route" : "p","message" : txt,
	"numbers" : str(ph)}
	headers={
	'cache-control':"no-cache"
	}
	response = requests.request("GET", url, headers=headers, params=querystring)
	print(response.text)
